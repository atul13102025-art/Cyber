"""Log parsers for LogGuard.

Supported formats
  * OpenSSH events in a syslog-style auth log (/var/log/auth.log or /var/log/secure)
  * Apache / Nginx "combined" access logs
"""
import ipaddress
import re
from datetime import datetime

MAX_LINES = 200_000
MAX_RAW = 300  # evidence lines are truncated to this many characters

SYSLOG_RE = re.compile(
    r"^(?P<ts>[A-Z][a-z]{2}\s+\d{1,2}\s\d{2}:\d{2}:\d{2})\s+(?P<host>\S+)\s+sshd(?:\[\d+\])?:\s+(?P<msg>.*)$")
FAILED_RE = re.compile(
    r"Failed (?:password|publickey|keyboard-interactive/pam) for (?P<inv>invalid user )?(?P<user>\S+) "
    r"from (?P<ip>[0-9a-fA-F:.]+) port")
INVALID_RE = re.compile(r"Invalid user (?P<user>\S*) from (?P<ip>[0-9a-fA-F:.]+)")
ACCEPT_RE = re.compile(
    r"Accepted (?:password|publickey|keyboard-interactive/pam) for (?P<user>\S+) "
    r"from (?P<ip>[0-9a-fA-F:.]+) port")

WEB_RE = re.compile(
    r'^(?P<ip>\S+) \S+ \S+ \[(?P<ts>[^\]]+)\] "(?P<method>[A-Z]+) (?P<path>\S+)(?: [^"]*)?" '
    r'(?P<status>\d{3}) (?P<size>\S+)(?: "(?P<ref>[^"]*)" "(?P<ua>[^"]*)")?')


def _valid_ip(text):
    try:
        return str(ipaddress.ip_address(text))
    except ValueError:
        return None


def _clip(line):
    line = line.strip()
    return line if len(line) <= MAX_RAW else line[:MAX_RAW] + "..."


def parse_ssh(text, year):
    """Return (events, stats). Syslog lines carry no year, so the caller supplies one."""
    events, parsed, total = [], 0, 0
    for line in text.splitlines()[:MAX_LINES]:
        if not line.strip():
            continue
        total += 1
        m = SYSLOG_RE.match(line)
        if not m:
            continue
        try:
            ts = datetime.strptime(f"{year} {' '.join(m.group('ts').split())}", "%Y %b %d %H:%M:%S")
        except ValueError:
            continue
        msg = m.group("msg")
        kind = user = ip = None
        invalid_user = False
        if (f := FAILED_RE.search(msg)):
            kind, user, ip = "ssh_fail", f.group("user"), f.group("ip")
            invalid_user = bool(f.group("inv"))
        elif (a := ACCEPT_RE.search(msg)):
            kind, user, ip = "ssh_ok", a.group("user"), a.group("ip")
        elif (i := INVALID_RE.search(msg)):
            kind, user, ip = "ssh_invalid", i.group("user"), i.group("ip")
            invalid_user = True
        if not kind:
            continue
        ip = _valid_ip(ip)
        if not ip:
            continue
        parsed += 1
        events.append({"kind": kind, "ts": ts, "ip": ip, "user": user[:64],
                       "invalid_user": invalid_user, "host": m.group("host"), "raw": _clip(line)})
    return events, {"total": total, "parsed": parsed}


def parse_web(text):
    """Return (events, stats) for combined-format access logs."""
    events, parsed, total = [], 0, 0
    for line in text.splitlines()[:MAX_LINES]:
        if not line.strip():
            continue
        total += 1
        m = WEB_RE.match(line)
        if not m:
            continue
        ip = _valid_ip(m.group("ip"))
        if not ip:
            continue
        try:
            ts = datetime.strptime(m.group("ts"), "%d/%b/%Y:%H:%M:%S %z")
        except ValueError:
            continue
        parsed += 1
        events.append({"kind": "web", "ts": ts.replace(tzinfo=None), "ip": ip,
                       "method": m.group("method"), "path": m.group("path")[:500],
                       "status": int(m.group("status")), "ua": (m.group("ua") or "")[:200],
                       "raw": _clip(line)})
    return events, {"total": total, "parsed": parsed}
