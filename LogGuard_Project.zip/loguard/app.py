"""LogGuard: upload SSH and web server logs, detect attacks, export a report.

Meant as a local analyst tool: it binds to 127.0.0.1 by default and has no user
accounts, so do not expose it to the internet without adding authentication.
Raw uploaded logs are analysed in memory and never saved; only the findings are stored.
"""
import csv
import io
import json
import os
import secrets
import sqlite3
from datetime import datetime

from flask import (Flask, Response, abort, flash, g, redirect, render_template,
                   request, session, url_for)

import detectors
import parsers
import sample_data

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("LOGUARD_DB", os.path.join(BASE_DIR, "data", "loguard.db"))
KEY_PATH = os.path.join(BASE_DIR, "data", ".secret_key")
MAX_UPLOAD = 5 * 1024 * 1024  # bytes

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 2 * MAX_UPLOAD + 64 * 1024  # two files plus form overhead
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax")


def _secret_key():
    if os.environ.get("SECRET_KEY"):
        return os.environ["SECRET_KEY"]
    os.makedirs(os.path.dirname(KEY_PATH), exist_ok=True)
    if not os.path.exists(KEY_PATH):
        with open(KEY_PATH, "w") as fh:
            fh.write(secrets.token_hex(32))
        os.chmod(KEY_PATH, 0o600)
    with open(KEY_PATH) as fh:
        return fh.read().strip()


app.secret_key = _secret_key()

SCHEMA = """
CREATE TABLE IF NOT EXISTS analyses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created TEXT NOT NULL,
    label TEXT NOT NULL,
    lines_total INTEGER NOT NULL,
    lines_parsed INTEGER NOT NULL,
    risk INTEGER NOT NULL,
    result TEXT NOT NULL
);
"""


def get_db():
    if "db" not in g:
        os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.executescript(SCHEMA)
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


# ----------------------------------------------------------------- security
def csrf_token():
    if "_csrf" not in session:
        session["_csrf"] = secrets.token_hex(16)
    return session["_csrf"]


app.jinja_env.globals["csrf_token"] = csrf_token


@app.before_request
def protect_post():
    if request.method == "POST":
        sent = request.form.get("_csrf", "")
        if not sent or not secrets.compare_digest(sent, session.get("_csrf", "")):
            abort(400, "Invalid or missing CSRF token.")


@app.after_request
def headers(resp):
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["X-Frame-Options"] = "DENY"
    resp.headers["Referrer-Policy"] = "same-origin"
    resp.headers["Cache-Control"] = "no-store"
    resp.headers["Content-Security-Policy"] = (
        "default-src 'self'; style-src 'self'; script-src 'none'; frame-ancestors 'none'")
    return resp


# ----------------------------------------------------------------- helpers
def save_analysis(label, stats, result):
    db = get_db()
    cur = db.execute(
        "INSERT INTO analyses (created, label, lines_total, lines_parsed, risk, result) VALUES (?,?,?,?,?,?)",
        (datetime.now().strftime("%Y-%m-%d %H:%M"), label, stats["total"], stats["parsed"],
         result["risk"], json.dumps(result)))
    db.commit()
    return cur.lastrowid


def run_analysis(ssh_text, web_text, year):
    ssh_events, s1 = parsers.parse_ssh(ssh_text, year) if ssh_text else ([], {"total": 0, "parsed": 0})
    web_events, s2 = parsers.parse_web(web_text) if web_text else ([], {"total": 0, "parsed": 0})
    stats = {"total": s1["total"] + s2["total"], "parsed": s1["parsed"] + s2["parsed"]}
    return stats, detectors.analyze(ssh_events, web_events)


def read_upload(field):
    f = request.files.get(field)
    if not f or not f.filename:
        return None
    data = f.read(MAX_UPLOAD + 1)
    if len(data) > MAX_UPLOAD:
        raise ValueError(f"{field}: file is larger than {MAX_UPLOAD // (1024 * 1024)} MB")
    if b"\x00" in data[:4096]:
        raise ValueError(f"{field}: this looks like a binary file, not a text log")
    return data.decode("utf-8", errors="replace")


def bar_rows(items, width=360):
    """items: [(label, value, css_class)] -> geometry for an SVG horizontal bar chart."""
    top = max([v for _, v, _ in items] + [1])
    return [{"label": l, "value": v, "cls": c, "w": round(width * v / top), "y": 28 * i}
            for i, (l, v, c) in enumerate(items)]


def timeline_geometry(timeline, height=140, width=640):
    if not timeline:
        return {"bars": [], "labels": [], "width": width, "height": height}
    top = max(t["ssh"] + t["web"] for t in timeline) or 1
    slot = width / len(timeline)
    bw = max(4, min(28, slot * 0.7))
    bars, labels = [], []
    step = max(1, len(timeline) // 8)
    for i, t in enumerate(timeline):
        x = round(i * slot + (slot - bw) / 2, 1)
        h_ssh = round((height - 20) * t["ssh"] / top, 1)
        h_web = round((height - 20) * t["web"] / top, 1)
        bars.append({"x": x, "w": round(bw, 1), "y": round(height - h_ssh, 1), "h": h_ssh, "cls": "bar-ssh",
                     "tip": f"{t['label']}: {t['ssh']} SSH failures"})
        bars.append({"x": x, "w": round(bw, 1), "y": round(height - h_ssh - h_web, 1), "h": h_web, "cls": "bar-web",
                     "tip": f"{t['label']}: {t['web']} flagged web requests"})
        if i % step == 0:
            labels.append({"x": round(x + bw / 2, 1), "text": t["label"]})
    return {"bars": bars, "labels": labels, "width": width, "height": height + 18}


def csv_safe(value):
    """Stop spreadsheet apps from running a cell as a formula (CSV injection)."""
    text = str(value)
    return "'" + text if text[:1] in ("=", "+", "-", "@", "\t", "\r") else text


def load_analysis(aid):
    row = get_db().execute("SELECT * FROM analyses WHERE id = ?", (aid,)).fetchone()
    if row is None:
        abort(404)
    return row, json.loads(row["result"])


# ----------------------------------------------------------------- routes
@app.route("/")
def index():
    rows = get_db().execute(
        "SELECT id, created, label, lines_parsed, risk FROM analyses ORDER BY id DESC LIMIT 20").fetchall()
    return render_template("index.html", rows=rows, risk_label=detectors.risk_label,
                           year=datetime.now().year, max_mb=MAX_UPLOAD // (1024 * 1024))


@app.route("/analyze", methods=["POST"])
def analyze_view():
    try:
        ssh_text, web_text = read_upload("authlog"), read_upload("weblog")
    except ValueError as exc:
        flash(str(exc), "error")
        return redirect(url_for("index"))
    if not ssh_text and not web_text:
        flash("Choose at least one log file to analyse.", "error")
        return redirect(url_for("index"))
    try:
        year = int(request.form.get("year", datetime.now().year))
        if not 1990 <= year <= 2100:
            raise ValueError
    except ValueError:
        flash("Enter a valid four-digit year.", "error")
        return redirect(url_for("index"))
    stats, result = run_analysis(ssh_text, web_text, year)
    if stats["parsed"] == 0:
        flash("No recognised log lines found. Expected OpenSSH auth log lines or Apache/Nginx combined format.", "error")
        return redirect(url_for("index"))
    label = " + ".join(n for n, t in (("SSH log", ssh_text), ("Web log", web_text)) if t)
    return redirect(url_for("analysis", aid=save_analysis(label, stats, result)))


@app.route("/sample", methods=["POST"])
def sample_view():
    year = datetime.now().year
    stats, result = run_analysis(sample_data.ssh_sample(year), sample_data.web_sample(year), year)
    return redirect(url_for("analysis", aid=save_analysis("Sample data (SSH + Web)", stats, result)))


@app.route("/analysis/<int:aid>")
def analysis(aid):
    row, result = load_analysis(aid)
    sev_items = [(s, result["by_severity"][s], "sev-" + s.lower()) for s in detectors.SEV_ORDER]
    ip_items = [(t["ip"], t["score"], "sev-high") for t in result["top_ips"]]
    return render_template(
        "analysis.html", row=row, r=result, label=detectors.risk_label(result["risk"]),
        sev_bars=bar_rows(sev_items), ip_bars=bar_rows(ip_items), tl=timeline_geometry(result["timeline"]))


@app.route("/analysis/<int:aid>/export.json")
def export_json(aid):
    row, result = load_analysis(aid)
    payload = {"id": row["id"], "created": row["created"], "label": row["label"],
               "risk": result["risk"], "by_severity": result["by_severity"], "findings": result["findings"]}
    return Response(json.dumps(payload, indent=2), mimetype="application/json",
                    headers={"Content-Disposition": f"attachment; filename=loguard-{aid}.json"})


@app.route("/analysis/<int:aid>/export.csv")
def export_csv(aid):
    _, result = load_analysis(aid)
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["severity", "rule", "title", "source_ip", "count", "first_seen", "last_seen", "mitre",
                "detail", "recommendation"])
    for f in result["findings"]:
        w.writerow([csv_safe(x) for x in (f["severity"], f["rule"], f["title"], f["ip"], f["count"],
                                          f["first_seen"], f["last_seen"], f["mitre"], f.get("detail", ""),
                                          f["recommendation"])])
    return Response(buf.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": f"attachment; filename=loguard-{aid}.csv"})


@app.route("/analysis/<int:aid>/delete", methods=["POST"])
def delete(aid):
    load_analysis(aid)
    db = get_db()
    db.execute("DELETE FROM analyses WHERE id = ?", (aid,))
    db.commit()
    flash("Analysis deleted.", "ok")
    return redirect(url_for("index"))


@app.errorhandler(400)
@app.errorhandler(404)
@app.errorhandler(413)
def handle_error(err):
    return render_template("error.html", err=err), err.code


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", 5000)),
            debug=os.environ.get("FLASK_DEBUG") == "1")
