"""Run with:  python -m unittest discover -s tests -v"""
import io
import json
import os
import re
import sys
import tempfile
import unittest
from datetime import datetime, timedelta

_tmp = tempfile.mkdtemp()
os.environ["LOGUARD_DB"] = os.path.join(_tmp, "test.db")
os.environ["SECRET_KEY"] = "test-secret"
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import app as lg  # noqa: E402
import detectors  # noqa: E402
import parsers  # noqa: E402
import sample_data  # noqa: E402


def ssh_line(t, msg):
    return f"{t.strftime('%b %d %H:%M:%S')} host sshd[1]: {msg}"


def web_line(ip, t, path, status=200, ua="Mozilla/5.0"):
    return f'{ip} - - [{t.strftime("%d/%b/%Y:%H:%M:%S")} +0000] "GET {path} HTTP/1.1" {status} 100 "-" "{ua}"'


T0 = datetime(2026, 10, 24, 3, 0, 0)


class ParserTests(unittest.TestCase):
    def test_ssh_kinds(self):
        text = "\n".join([
            ssh_line(T0, "Failed password for root from 203.0.113.5 port 22 ssh2"),
            ssh_line(T0, "Failed password for invalid user bob from 203.0.113.5 port 22 ssh2"),
            ssh_line(T0, "Invalid user alice from 203.0.113.6 port 22"),
            ssh_line(T0, "Accepted publickey for deploy from 10.0.0.4 port 22 ssh2"),
            "garbage line", ssh_line(T0, "Connection closed by 10.0.0.9"),
        ])
        ev, st = parsers.parse_ssh(text, 2026)
        self.assertEqual([e["kind"] for e in ev], ["ssh_fail", "ssh_fail", "ssh_invalid", "ssh_ok"])
        self.assertTrue(ev[1]["invalid_user"])
        self.assertEqual(st, {"total": 6, "parsed": 4})

    def test_bad_ip_skipped(self):
        ev, _ = parsers.parse_ssh(ssh_line(T0, "Failed password for root from 999.1.1.1 port 22 ssh2"), 2026)
        self.assertEqual(ev, [])

    def test_web(self):
        ev, st = parsers.parse_web(web_line("192.0.2.1", T0, "/a?b=1", 404, "curl/8") + "\nnot a log\n")
        self.assertEqual((ev[0]["ip"], ev[0]["status"], ev[0]["ua"]), ("192.0.2.1", 404, "curl/8"))
        self.assertEqual(st, {"total": 2, "parsed": 1})


class DetectorTests(unittest.TestCase):
    def run_ssh(self, lines):
        ev, _ = parsers.parse_ssh("\n".join(lines), 2026)
        return detectors.detect_ssh(ev)

    def test_densest_window(self):
        times = [T0 + timedelta(seconds=s) for s in (0, 10, 20, 500, 505)]
        self.assertEqual(detectors.densest_window(times, 60)[0], 3)

    def test_brute_force_threshold(self):
        few = [ssh_line(T0 + timedelta(seconds=i), "Failed password for root from 203.0.113.9 port 1 ssh2") for i in range(4)]
        self.assertEqual(self.run_ssh(few), [])
        many = [ssh_line(T0 + timedelta(seconds=i), "Failed password for root from 203.0.113.9 port 1 ssh2") for i in range(5)]
        self.assertEqual([f["rule"] for f in self.run_ssh(many)], ["SSH_BRUTE_FORCE"])

    def test_slow_failures_not_flagged(self):
        slow = [ssh_line(T0 + timedelta(seconds=400 * i), "Failed password for root from 203.0.113.9 port 1 ssh2") for i in range(6)]
        self.assertEqual(self.run_ssh(slow), [])

    def test_success_after_failures_is_critical(self):
        lines = [ssh_line(T0 + timedelta(seconds=i), "Failed password for deploy from 203.0.113.9 port 1 ssh2") for i in range(3)]
        lines.append(ssh_line(T0 + timedelta(seconds=10), "Accepted password for deploy from 203.0.113.9 port 1 ssh2"))
        f = self.run_ssh(lines)
        self.assertEqual(f[0]["rule"], "SSH_SUCCESS_AFTER_FAILS")
        self.assertEqual(f[0]["severity"], "Critical")

    def test_enumeration(self):
        lines = [ssh_line(T0 + timedelta(seconds=i), f"Invalid user u{i} from 198.51.100.4 port 1") for i in range(3)]
        self.assertEqual([f["rule"] for f in self.run_ssh(lines)], ["SSH_USER_ENUMERATION"])

    def classify(self, path, ua="Mozilla/5.0"):
        return detectors.classify_web({"path": path, "ua": ua})

    def test_web_tags(self):
        self.assertIn("sqli", self.classify("/p?id=1%27%20OR%20%271%27=%271"))
        self.assertIn("sqli", self.classify("/p?id=1+UNION+SELECT+1,2"))
        self.assertIn("sqli", self.classify("/p?id=%2527%2520or%2520%25271%2527=%25271"))  # double encoded
        self.assertIn("xss", self.classify("/s?q=%3Cscript%3Ealert(1)%3C/script%3E"))
        self.assertIn("traversal", self.classify("/d?f=../../etc/passwd"))
        self.assertIn("cmdi", self.classify("/ping?h=8.8.8.8;cat+/etc/passwd"))
        self.assertIn("scanner", self.classify("/", ua="sqlmap/1.7"))
        self.assertIn("sensitive", self.classify("/.env"))

    def test_web_benign(self):
        for p in ["/", "/products?id=42", "/search?q=select+a+shirt", "/about-us", "/blog/union-rules"]:
            self.assertEqual(self.classify(p), [], p)

    def test_sqli_severity_depends_on_status(self):
        ev = [{"kind": "web", "ts": T0, "ip": "192.0.2.1", "path": "/p?id=1'+or+'1'='1", "status": 200, "ua": "", "raw": "r"}]
        self.assertEqual(detectors.detect_web(ev)[0]["severity"], "High")
        ev[0]["status"] = 403
        self.assertEqual(detectors.detect_web(ev)[0]["severity"], "Medium")

    def test_404_flood(self):
        text = "\n".join(web_line("192.0.2.8", T0 + timedelta(seconds=i), f"/x{i}", 404) for i in range(20))
        ev, _ = parsers.parse_web(text)
        self.assertIn("WEB_404_FLOOD", [f["rule"] for f in detectors.detect_web(ev)])

    def test_sample_data_expected_findings(self):
        se, _ = parsers.parse_ssh(sample_data.ssh_sample(2026), 2026)
        we, _ = parsers.parse_web(sample_data.web_sample(2026))
        res = detectors.analyze(se, we)
        rules = {f["rule"] for f in res["findings"]}
        for needed in ("SSH_SUCCESS_AFTER_FAILS", "SSH_BRUTE_FORCE", "SSH_USER_ENUMERATION", "WEB_SQLI", "WEB_SCANNER",
                       "WEB_404_FLOOD", "WEB_XSS", "WEB_TRAVERSAL", "WEB_CMDI", "WEB_SENSITIVE_PROBE"):
            self.assertIn(needed, rules)
        self.assertEqual(res["findings"][0]["severity"], "Critical")
        self.assertIn("203.0.113.45", res["block_ips"])
        # benign admin logins and typos from the private range must not be flagged
        self.assertNotIn("10.0.0.15", {f["ip"] for f in res["findings"]})

    def test_sample_is_deterministic(self):
        self.assertEqual(sample_data.web_sample(2026), sample_data.web_sample(2026))


def token(client):
    html = client.get("/").get_data(as_text=True)
    return re.search(r'name="_csrf" value="([^"]+)"', html).group(1)


class AppTests(unittest.TestCase):
    def setUp(self):
        self.c = lg.app.test_client()

    def post(self, url, **kw):
        data = kw.pop("data", {})
        data["_csrf"] = token(self.c)
        return self.c.post(url, data=data, **kw)

    def test_index(self):
        r = self.c.get("/")
        self.assertEqual(r.status_code, 200)
        self.assertIn("script-src 'none'", r.headers["Content-Security-Policy"])
        self.assertEqual(r.headers["X-Frame-Options"], "DENY")

    def test_csrf_required(self):
        self.assertEqual(self.c.post("/sample").status_code, 400)

    def test_sample_flow_and_exports(self):
        r = self.post("/sample")
        self.assertEqual(r.status_code, 302)
        page = self.c.get(r.headers["Location"])
        self.assertEqual(page.status_code, 200)
        html = page.get_data(as_text=True)
        self.assertIn("Successful SSH login after repeated failures", html)
        aid = r.headers["Location"].rsplit("/", 1)[1]
        j = json.loads(self.c.get(f"/analysis/{aid}/export.json").get_data(as_text=True))
        self.assertEqual(j["findings"][0]["severity"], "Critical")
        csv_text = self.c.get(f"/analysis/{aid}/export.csv").get_data(as_text=True)
        self.assertTrue(csv_text.startswith("severity,rule"))

    def test_upload_files(self):
        data = {"authlog": (io.BytesIO(sample_data.ssh_sample(2026).encode()), "auth.log"),
                "weblog": (io.BytesIO(sample_data.web_sample(2026).encode()), "access.log"),
                "year": "2026", "_csrf": token(self.c)}
        r = self.c.post("/analyze", data=data, content_type="multipart/form-data")
        self.assertEqual(r.status_code, 302)
        self.assertIn("/analysis/", r.headers["Location"])

    def post_upload(self, files, year="2026"):
        data = dict(files, year=year, _csrf=token(self.c))
        return self.c.post("/analyze", data=data, content_type="multipart/form-data", follow_redirects=True)

    def test_rejects_empty_binary_unrecognised_and_bad_year(self):
        self.assertIn("at least one log file", self.post_upload({}).get_data(as_text=True))
        binary = {"authlog": (io.BytesIO(b"\x00\x01\x02" * 100), "x.bin")}
        self.assertIn("binary file", self.post_upload(binary).get_data(as_text=True))
        junk = {"weblog": (io.BytesIO(b"hello world\nnothing here\n"), "x.log")}
        self.assertIn("No recognised log lines", self.post_upload(junk).get_data(as_text=True))
        ok = {"authlog": (io.BytesIO(sample_data.ssh_sample(2026).encode()), "a.log")}
        self.assertIn("valid four-digit year", self.post_upload(ok, year="abc").get_data(as_text=True))

    def test_oversize_rejected(self):
        big = b"a" * (lg.MAX_UPLOAD + 10)
        r = self.post_upload({"authlog": (io.BytesIO(big), "big.log")})
        self.assertIn("larger than", r.get_data(as_text=True))

    def test_evidence_is_html_escaped(self):
        line = web_line("192.0.2.5", T0, "/s?q=<script>alert(1)</script>", 200)
        r = self.post_upload({"weblog": (io.BytesIO(line.encode()), "w.log")})
        html = r.get_data(as_text=True)
        self.assertIn("&lt;script&gt;alert(1)&lt;/script&gt;", html)
        self.assertNotIn("<script>alert(1)</script>", html)

    def test_csv_formula_escape(self):
        self.assertEqual(lg.csv_safe("=1+1"), "'=1+1")
        self.assertEqual(lg.csv_safe("@x"), "'@x")
        self.assertEqual(lg.csv_safe("normal"), "normal")

    def test_delete_and_404(self):
        r = self.post("/sample")
        aid = r.headers["Location"].rsplit("/", 1)[1]
        self.post(f"/analysis/{aid}/delete")
        self.assertEqual(self.c.get(f"/analysis/{aid}").status_code, 404)
        self.assertEqual(self.c.get("/analysis/999999").status_code, 404)


if __name__ == "__main__":
    unittest.main()
