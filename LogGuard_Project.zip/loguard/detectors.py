"""Detection rules for LogGuard.

Every rule is defensive: it looks for evidence of attacks inside logs you already
own and returns findings with severity, MITRE ATT&CK mapping and a recommendation.
"""
import re
from collections import defaultdict
from urllib.parse import unquote_plus

SEV_ORDER = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3}
SEV_WEIGHT = {"Critical": 25, "High": 10, "Medium": 4, "Low": 1}

CFG = {
    "ssh_bf_count": 5,        # failures from one IP ...
    "ssh_bf_window": 300,     # ... within this many seconds
    "enum_users": 3,          # distinct unknown usernames from one IP
    "success_after_fail": 3,  # failures before a success ...
    "success_window": 600,    # ... within this many seconds
    "flood_404": 20,          # 404 responses from one IP ...
    "flood_window": 60,       # ... within this many seconds
}

SQLI = re.compile(
    r"(union(\s|\+|/\*.*?\*/)+(all\s+)?select|select\s.+\sfrom\s|information_schema|sleep\(\s*\d|benchmark\(|"
    r"\bor\s+'?\d+'?\s*=\s*'?\d+|'\s*or\s*'|;\s*drop\s+table|xp_cmdshell|--\s*$)", re.I)
XSS = re.compile(r"(<script|javascript:|onerror\s*=|onload\s*=|<img[^>]+src|<svg[^>]+onload)", re.I)
TRAVERSAL = re.compile(r"(\.\./|\.\.\\|/etc/passwd|/etc/shadow|boot\.ini|win\.ini)", re.I)
CMDI = re.compile(r"((;|\|\||&&|\|)\s*(cat|ls|id|whoami|wget|curl|nc|bash|sh)\b|`[^`]+`|\$\([^)]+\))", re.I)
SCANNER_UA = re.compile(r"(sqlmap|nikto|nmap|masscan|dirbuster|gobuster|wfuzz|acunetix|nessus|zgrab|hydra)", re.I)
SENSITIVE = re.compile(
    r"(/\.env|/\.git/|/wp-login\.php|/xmlrpc\.php|/phpmyadmin|/admin(/|$)|/config\.php|"
    r"/backup\.(zip|sql|tar)|/server-status)", re.I)

RULES = {
    "SSH_BRUTE_FORCE": ("SSH brute force", "T1110",
        "Block the source at the firewall, enforce key-based auth, and add fail2ban or rate limiting."),
    "SSH_SUCCESS_AFTER_FAILS": ("Successful SSH login after repeated failures", "T1078",
        "Treat the account as compromised: reset credentials, review the session and revoke keys."),
    "SSH_USER_ENUMERATION": ("SSH username enumeration", "T1087",
        "Disable password auth, restrict AllowUsers, and block the source."),
    "WEB_SQLI": ("SQL injection attempt", "T1190",
        "Use parameterised queries, enable a WAF, and check database logs if any request returned 200."),
    "WEB_XSS": ("Cross-site scripting attempt", "T1190",
        "Encode output, add a Content-Security-Policy, and validate input."),
    "WEB_TRAVERSAL": ("Path traversal attempt", "T1190",
        "Canonicalise file paths, deny access outside the web root and patch the application."),
    "WEB_CMDI": ("Command injection attempt", "T1190",
        "Never pass input to a shell; review the endpoint and check the host for unexpected processes."),
    "WEB_SCANNER": ("Vulnerability scanner traffic", "T1595",
        "Confirm it is not your own authorised scan; otherwise block the source and rate limit."),
    "WEB_404_FLOOD": ("Burst of 404 errors (content discovery)", "T1595",
        "Rate limit the source and review which paths exist that should not be public."),
    "WEB_SENSITIVE_PROBE": ("Probing for sensitive files and admin pages", "T1595",
        "Make sure these paths are not exposed; restrict admin interfaces by IP or VPN."),
}


def densest_window(times, window):
    """Largest number of events inside any `window` seconds. Returns (count, start_idx, end_idx)."""
    best, j = (0, 0, 0), 0
    for i, t in enumerate(times):
        while (t - times[j]).total_seconds() > window:
            j += 1
        if i - j + 1 > best[0]:
            best = (i - j + 1, j, i)
    return best


def _finding(rule, severity, ip, count, events, extra=None):
    title, mitre, rec = RULES[rule]
    events = sorted(events, key=lambda e: e["ts"])
    f = {
        "id": f"{rule}:{ip}", "rule": rule, "title": title, "severity": severity, "ip": ip,
        "count": count, "first_seen": events[0]["ts"].isoformat(sep=" "),
        "last_seen": events[-1]["ts"].isoformat(sep=" "), "mitre": mitre,
        "evidence": [e["raw"] for e in events[:3]], "recommendation": rec,
    }
    if extra:
        f["detail"] = extra
    return f


# --------------------------------------------------------------------------- SSH
def detect_ssh(events):
    findings = []
    by_ip = defaultdict(list)
    for e in events:
        by_ip[e["ip"]].append(e)
    for ip, evs in by_ip.items():
        evs.sort(key=lambda e: e["ts"])
        fails = [e for e in evs if e["kind"] == "ssh_fail"]
        oks = [e for e in evs if e["kind"] == "ssh_ok"]

        if len(fails) >= CFG["ssh_bf_count"]:
            n, a, b = densest_window([e["ts"] for e in fails], CFG["ssh_bf_window"])
            if n >= CFG["ssh_bf_count"]:
                users = sorted({e["user"] for e in fails})
                findings.append(_finding("SSH_BRUTE_FORCE", "High", ip, len(fails), fails,
                                         f"{n} failures within {CFG['ssh_bf_window']}s; users tried: "
                                         f"{', '.join(users[:5])}"))

        unknown = {e["user"] for e in evs if e.get("invalid_user")}
        if len(unknown) >= CFG["enum_users"]:
            inv = [e for e in evs if e.get("invalid_user")]
            findings.append(_finding("SSH_USER_ENUMERATION", "Medium", ip, len(unknown), inv,
                                     f"{len(unknown)} distinct unknown usernames"))

        for ok in oks:
            window = [f for f in fails if 0 <= (ok["ts"] - f["ts"]).total_seconds() <= CFG["success_window"]]
            if len(window) >= CFG["success_after_fail"]:
                findings.append(_finding("SSH_SUCCESS_AFTER_FAILS", "Critical", ip, len(window) + 1,
                                         window + [ok],
                                         f"user '{ok['user']}' logged in after {len(window)} failures"))
                break
    return findings


# --------------------------------------------------------------------------- web
def classify_web(event):
    """Return the list of attack tags for one web event."""
    target = unquote_plus(unquote_plus(event["path"]))
    tags = []
    if SQLI.search(target):
        tags.append("sqli")
    if XSS.search(target):
        tags.append("xss")
    if TRAVERSAL.search(target):
        tags.append("traversal")
    if CMDI.search(target):
        tags.append("cmdi")
    if SCANNER_UA.search(event.get("ua", "")):
        tags.append("scanner")
    if SENSITIVE.search(target):
        tags.append("sensitive")
    return tags


TAG_RULE = {"sqli": "WEB_SQLI", "xss": "WEB_XSS", "traversal": "WEB_TRAVERSAL", "cmdi": "WEB_CMDI",
            "scanner": "WEB_SCANNER", "sensitive": "WEB_SENSITIVE_PROBE"}


def detect_web(events):
    findings = []
    grouped = defaultdict(list)       # (ip, tag) -> events
    not_found = defaultdict(list)     # ip -> 404 events
    for e in events:
        e["tags"] = classify_web(e)
        for t in e["tags"]:
            grouped[(e["ip"], t)].append(e)
        if e["status"] == 404:
            not_found[e["ip"]].append(e)

    for (ip, tag), evs in grouped.items():
        succeeded = [e for e in evs if e["status"] == 200]
        if tag in ("sqli", "cmdi", "traversal"):
            sev = "High" if succeeded else "Medium"
            note = f"{len(succeeded)} request(s) returned HTTP 200" if succeeded else "all requests were rejected"
        elif tag in ("xss", "scanner"):
            sev, note = "Medium", None
        else:
            sev, note = "Low", None
        findings.append(_finding(TAG_RULE[tag], sev, ip, len(evs), evs, note))

    for ip, evs in not_found.items():
        evs.sort(key=lambda e: e["ts"])
        n, a, b = densest_window([e["ts"] for e in evs], CFG["flood_window"])
        if n >= CFG["flood_404"]:
            findings.append(_finding("WEB_404_FLOOD", "Medium", ip, n, evs[a:b + 1],
                                     f"{n} 404 responses within {CFG['flood_window']}s"))
    return findings


# --------------------------------------------------------------------------- summary
def analyze(ssh_events, web_events):
    """Run all detectors and build the summary used by the UI and exports."""
    findings = detect_ssh(ssh_events) + detect_web(web_events)
    findings.sort(key=lambda f: (SEV_ORDER[f["severity"]], -f["count"], f["ip"]))

    by_sev = {s: 0 for s in SEV_ORDER}
    for f in findings:
        by_sev[f["severity"]] += 1
    risk = min(100, sum(SEV_WEIGHT[f["severity"]] for f in findings))

    ip_score = defaultdict(lambda: {"score": 0, "rules": []})
    for f in findings:
        ip_score[f["ip"]]["score"] += SEV_WEIGHT[f["severity"]]
        ip_score[f["ip"]]["rules"].append(f["title"])
    top_ips = sorted(({"ip": ip, **v} for ip, v in ip_score.items()), key=lambda x: -x["score"])[:5]

    block = sorted({f["ip"] for f in findings if f["severity"] in ("Critical", "High")})

    buckets = defaultdict(lambda: {"ssh": 0, "web": 0})
    all_times = [e["ts"] for e in ssh_events + web_events]
    daily = bool(all_times) and (max(all_times) - min(all_times)).total_seconds() > 72 * 3600
    fmt = "%Y-%m-%d" if daily else "%m-%d %H:00"
    for e in ssh_events:
        if e["kind"] == "ssh_fail":
            buckets[e["ts"].strftime(fmt)]["ssh"] += 1
    for e in web_events:
        if e.get("tags"):
            buckets[e["ts"].strftime(fmt)]["web"] += 1
    timeline = [{"label": k, **v} for k, v in sorted(buckets.items())]

    return {
        "findings": findings, "by_severity": by_sev, "risk": risk, "top_ips": top_ips,
        "block_ips": block, "timeline": timeline, "granularity": "day" if daily else "hour",
        "unique_ips": len({e["ip"] for e in ssh_events + web_events}),
        "events": {"ssh": len(ssh_events), "web": len(web_events)},
    }


def risk_label(score):
    if score >= 75:
        return "Critical"
    if score >= 40:
        return "High"
    if score >= 15:
        return "Medium"
    return "Low"
