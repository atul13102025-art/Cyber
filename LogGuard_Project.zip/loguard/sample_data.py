"""Deterministic synthetic logs for demos and tests.

All IP addresses are from the RFC 5737 documentation ranges or private ranges,
and every host and user name is fictional.
"""
import random
import zlib
from datetime import datetime, timedelta
from urllib.parse import quote

UA_BROWSER = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/118.0 Safari/537.36"


def _syslog(t, msg, host="web01", pid=2200):
    return f"{t.strftime('%b %d %H:%M:%S')} {host} sshd[{pid}]: {msg}"


def ssh_sample(year=2026):
    rnd = random.Random(7)
    day = datetime(year, 10, 24)
    lines = []

    # Normal activity
    for hour, user, ip in [(8, "alice", "10.0.0.15"), (9, "bob", "10.0.0.22"), (13, "alice", "10.0.0.15"),
                           (17, "deploy", "10.0.0.40")]:
        t = day + timedelta(hours=hour, minutes=rnd.randint(0, 59))
        lines.append((t, _syslog(t, f"Accepted publickey for {user} from {ip} port {rnd.randint(40000, 60000)} ssh2")))
    # Harmless typo
    t = day + timedelta(hours=8, minutes=40)
    for k in range(2):
        tt = t + timedelta(seconds=20 * k)
        lines.append((tt, _syslog(tt, f"Failed password for alice from 10.0.0.15 port {50000 + k} ssh2")))

    # Brute force that ends in a successful login
    t = day + timedelta(hours=3, minutes=12)
    for k in range(14):
        tt = t + timedelta(seconds=9 * k)
        user = "deploy" if k > 5 else rnd.choice(["root", "admin", "ubuntu"])
        inv = "" if user in ("root", "deploy") else "invalid user "
        lines.append((tt, _syslog(tt, f"Failed password for {inv}{user} from 203.0.113.45 port {41000 + k} ssh2")))
    tt = t + timedelta(seconds=9 * 14 + 4)
    lines.append((tt, _syslog(tt, "Accepted password for deploy from 203.0.113.45 port 41999 ssh2")))

    # Username enumeration
    t = day + timedelta(hours=4, minutes=30)
    for k, name in enumerate(["test", "oracle", "git", "postgres", "ftpuser", "guest", "pi", "user1"]):
        tt = t + timedelta(seconds=15 * k)
        lines.append((tt, _syslog(tt, f"Invalid user {name} from 198.51.100.77 port {52000 + k}")))

    lines.sort(key=lambda x: x[0])
    return "\n".join(l for _, l in lines) + "\n"


def _web(ip, t, path, status, ua=UA_BROWSER, method="GET", size=None, tz="+0530"):
    size = size if size is not None else 180 + zlib.crc32(f"{ip}{path}".encode()) % 8800
    return (t, f'{ip} - - [{t.strftime("%d/%b/%Y:%H:%M:%S")} {tz}] "{method} {path} HTTP/1.1" {status} {size} "-" "{ua}"')


def web_sample(year=2026):
    rnd = random.Random(11)
    day = datetime(year, 10, 24)
    rows = []

    # Normal traffic
    pages = ["/", "/products", "/about", "/contact", "/static/site.css", "/products/42"]
    for k in range(60):
        t = day + timedelta(hours=rnd.randint(0, 23), minutes=rnd.randint(0, 59), seconds=rnd.randint(0, 59))
        ip = f"192.0.2.{rnd.randint(10, 40)}"
        rows.append(_web(ip, t, rnd.choice(pages), 200))

    # SQL injection (one request succeeds)
    t = day + timedelta(hours=1, minutes=5)
    for k, payload in enumerate(["1' OR '1'='1", "1 UNION SELECT username,password FROM users--",
                                 "1; DROP TABLE users", "1' AND SLEEP(5)--"]):
        tt = t + timedelta(seconds=7 * k)
        rows.append(_web("192.0.2.150", tt, "/products.php?id=" + quote(payload, safe="="), 200 if k == 1 else 500))

    # Scanner using a recognisable user agent
    t = day + timedelta(hours=2, minutes=10)
    for k, p in enumerate(["/", "/login", "/search?q=1", "/admin", "/api/v1/users"]):
        tt = t + timedelta(seconds=2 * k)
        rows.append(_web("192.0.2.99", tt, p, 200 if k < 2 else 404, ua="sqlmap/1.7.2#stable (https://sqlmap.org)"))

    # Content discovery: 404 flood plus sensitive file probing
    t = day + timedelta(hours=5, minutes=0)
    for k in range(45):
        tt = t + timedelta(seconds=k)
        rows.append(_web("198.51.100.200", tt, f"/{rnd.choice(['old', 'bak', 'dev', 'test', 'tmp'])}{k}.php", 404))
    for k, p in enumerate(["/.env", "/wp-login.php", "/phpmyadmin/", "/.git/config", "/backup.zip"]):
        tt = t + timedelta(seconds=50 + k)
        rows.append(_web("198.51.100.200", tt, p, 404))

    # XSS, traversal, command injection
    t = day + timedelta(hours=6, minutes=20)
    rows.append(_web("192.0.2.77", t, "/search?q=" + quote("<script>alert(1)</script>", safe="="), 200))
    rows.append(_web("192.0.2.77", t + timedelta(seconds=5), "/download?file=" + quote("../../../etc/passwd", safe="=/"), 400))
    rows.append(_web("192.0.2.77", t + timedelta(seconds=9), "/ping?host=" + quote("8.8.8.8;cat /etc/passwd", safe="="), 500))

    rows.sort(key=lambda x: x[0])
    return "\n".join(l for _, l in rows) + "\n"
